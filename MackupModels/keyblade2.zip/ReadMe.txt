This model was ripped by Zerox. I also regrouped some textures and updated the UVmap to make the model use less textures.
No credit necessary though I really prefer if you do give me credit. 
If you do something cool with the model send me a private message on Spriter's Resource, I'd love to see.