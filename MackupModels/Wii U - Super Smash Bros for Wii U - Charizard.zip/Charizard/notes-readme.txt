Credit to Random Talking Bush of the VG-Resource for writing the MaxScript and tools needed for this rip.
Ripped by ThatTrueStruggle of VG-Resource
All rights go to Nintendo :P

----------Notes------------
The _composite maps are a diffuse map with the Ambient Occlusion and Normal Map overlaid on top of the diffuse map. Reason for only the default costume  having them is because I only needed the _comp maps for rendering out the previews :P

Diffuse Map + Normal Map (Desaturated + Overlay) + Ambient Occlusion Map (Full Brightness + Multiply) = Composite Map (Full Detail)
All of this was done in Paint.NET, Noesis and Autodesk 3DS Max. 